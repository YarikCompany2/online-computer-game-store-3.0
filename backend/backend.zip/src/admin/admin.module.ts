import { Module } from '@nestjs/common';
import { AdminService } from './admin.service';
import { AdminController } from './admin.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from '../users/entities/user.entity';
import { Game } from '../games/entities/game.entity';
import { Order } from '../orders/entities/order.entity';
import { Company } from '../companies/entities/company.entity';
import { Notification } from '../notification/entities/notification.entity';
import { Discount } from '../discounts/entities/discount.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([User, Game, Order, Company, Notification, Discount])
  ],
  controllers: [AdminController],
  providers: [AdminService],
})
export class AdminModule {}
