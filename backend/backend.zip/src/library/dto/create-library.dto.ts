export class CreateLibraryDto {}
