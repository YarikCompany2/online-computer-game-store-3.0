export class CreatePlatformDto {}
